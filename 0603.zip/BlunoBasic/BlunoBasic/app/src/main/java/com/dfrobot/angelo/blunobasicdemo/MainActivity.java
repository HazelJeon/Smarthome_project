package com.dfrobot.angelo.blunobasicdemo;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.graphics.Color;
import android.os.Bundle;
import java.lang.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.net.Uri;

public class MainActivity extends BlunoLibrary

{
    private Button buttonScan;
    private Button buttonLed;
    private Button switchBell;
    private Button switchBell2;
    private Button switchBell3;
    private Button switchBell4;
    private TextView dateNow;
    private TextView dateNow2;
    private TextView dateNow3;
    private TextView dateNow4;
    private Button bemergency;
    private TextView serial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        onCreateProcess();                                                        //onCreate Process by BlunoLibrary
        serialBegin(115200);                                                    //set the Uart Baudrate on BLE chip to 115200

        dateNow = (TextView) findViewById(R.id.dateNow);
        dateNow2 = (TextView) findViewById(R.id.dateNow2);
        dateNow3 = (TextView) findViewById(R.id.dateNow3);
        dateNow4 = (TextView) findViewById(R.id.dateNow4);
        serial = (TextView)findViewById(R.id.serial);


        buttonScan = (Button) findViewById(R.id.buttonScan);                    //initial the button for scanning the BLE device
        buttonScan.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                buttonScanOnClickProcess();                                        //Alert Dialog for selecting the BLE device
            }
        });


        bemergency=(Button) findViewById(R.id.bemergency);
        bemergency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                //메인 페이지에서 다른 페이지생성 및 전환이 필요할때 사용하는 객체이다.
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:/119"));        //Uri 를 이용하여 웹브라우저를 통해 웹페이지로 이동하는 기능
                startActivity((mIntent));
            }
        });

        switchBell = (Button) findViewById(R.id.switchBell);
        switchBell.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (switchBell.getText().equals("OFF")) {
                    Toast.makeText(getApplicationContext(), "Nobody pressed doorbell. ", Toast.LENGTH_LONG).show();
                } else if (switchBell.getText().equals("ON")) {
                    switchBell.setBackgroundColor(Color.BLACK);
                    switchBell.setText("OFF");
                    dateNow.setText(" ");
                }                                //Alert Dialog for selecting the BLE device
            }
        });

        switchBell2 = (Button) findViewById(R.id.switchBell2);
        switchBell2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (switchBell2.getText().equals("OFF")) {
                    Toast.makeText(getApplicationContext(), "Nobody knocked the door.", Toast.LENGTH_LONG).show();
                } else if (switchBell2.getText().equals("ON")) {
                    switchBell2.setBackgroundColor(Color.BLACK);
                    switchBell2.setText("OFF");
                    dateNow2.setText(" ");
                }                                //Alert Dialog for selecting the BLE device
            }
        });


        switchBell3 = (Button) findViewById(R.id.switchBell3);
        switchBell3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (switchBell3.getText().equals("OFF")) {
                    Toast.makeText(getApplicationContext(), "Nobody come to your house.", Toast.LENGTH_LONG).show();
                } else if (switchBell3.getText().equals("ON")) {
                    switchBell3.setBackgroundColor(Color.BLACK);
                    switchBell3.setText("OFF");
                    dateNow3.setText(" ");
                }                                //Alert Dialog for selecting the BLE device
            }
        });

        switchBell4 = (Button) findViewById(R.id.switchBell4);
        switchBell4.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (switchBell4.getText().equals("OFF")) {
                    Toast.makeText(getApplicationContext(), "A fire doesn't break out.", Toast.LENGTH_LONG).show();
                } else if (switchBell4.getText().equals("ON")) {
                    switchBell4.setBackgroundColor(Color.BLACK);
                    switchBell4.setText("OFF");
                    dateNow4.setText(" ");
                }                                //Alert Dialog for selecting the BLE device
            }
        });
        buttonLed = (Button) findViewById(R.id.buttonLed);
        buttonLed.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                // TODO Auto-generated method stub
                if ( buttonLed.getText().equals("RESET")) {
                    //serialSend("0");//Alert Dialog for selecting the BLE device
                    switchBell.setBackgroundColor(Color.BLACK);
                    switchBell.setText("OFF");
                    dateNow.setText(" ");
                    switchBell2.setBackgroundColor(Color.BLACK);
                    switchBell2.setText("OFF");
                    dateNow2.setText(" ");
                    switchBell3.setBackgroundColor(Color.BLACK);
                    switchBell3.setText("OFF");
                    dateNow3.setText(" ");
                    switchBell4.setBackgroundColor(Color.BLACK);
                    switchBell4.setText("OFF");
                    dateNow4.setText(" ");

                }
                }

        });


    }

    protected void onResume() {
        super.onResume();
        System.out.println("BlUNOActivity onResume");
        onResumeProcess();                                                        //onResume Process by BlunoLibrary
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        onActivityResultProcess(requestCode, resultCode, data);                    //onActivityResult Process by BlunoLibrary
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onPause() {
        super.onPause();
        onPauseProcess();                                                        //onPause Process by BlunoLibrary
    }

    protected void onStop() {
        super.onStop();
        onStopProcess();                                                        //onStop Process by BlunoLibrary
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        onDestroyProcess();                                                        //onDestroy Process by BlunoLibrary
    }

    @Override
    public void onConectionStateChange(connectionStateEnum theConnectionState) {//Once connection state changes, this function will be called
        switch (theConnectionState) {                                            //Four connection state
            case isConnected:
                buttonScan.setText("Connected");
                break;
            case isConnecting:
                buttonScan.setText("Connecting");
                break;
            case isToScan:
                buttonScan.setText("Scan");
                break;
            case isScanning:
                buttonScan.setText("Scanning");
                break;
            case isDisconnecting:
                buttonScan.setText("isDisconnecting");
                break;
            default:
                break;
        }
    }

    @Override
    public void onSerialReceived(String theString) {                            //Once connection data received, this function will be called
        serial.append(theString);
        if (theString.equals("1")) {
            switchBell.setText("ON");
            switchBell.setBackgroundColor(Color.GREEN);

            long now = System.currentTimeMillis();
            Date date = new Date(now);
            SimpleDateFormat sdfNow = new SimpleDateFormat("MM/dd HH:mm:ss");
            String formatDate = sdfNow.format(date);
            dateNow.setText(formatDate);    // TextView 에 현재 시간 문자열 할당

            NotificationManager notificationmanager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Intent intent1 = new Intent(MainActivity.this.getApplicationContext(), MainActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingNotificationIntent = PendingIntent.getActivity(MainActivity.this, 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder builder = new Notification.Builder(getApplicationContext());
            builder.setSmallIcon(R.drawable.on).setTicker("DoorBell Alarm").setWhen(System.currentTimeMillis())
                    .setNumber(1).setContentTitle("알림").setContentText(formatDate + "에 초인종이 눌렸습니다.")
                    .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE).setContentIntent(pendingNotificationIntent).setAutoCancel(true);

            notificationmanager.notify(1, builder.build());

        }

        if (theString.equals("2")) {
            switchBell2.setText("ON");
            switchBell2.setBackgroundColor(Color.GREEN);

            long now = System.currentTimeMillis();
            Date date = new Date(now);
            SimpleDateFormat sdfNow = new SimpleDateFormat("MM/dd HH:mm:ss");
            String formatDate = sdfNow.format(date);

            dateNow2.setText(formatDate);    // TextView 에 현재 시간 문자열 할당

            NotificationManager notificationmanager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Intent intent1 = new Intent(MainActivity.this.getApplicationContext(), MainActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingNotificationIntent = PendingIntent.getActivity(MainActivity.this, 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder builder = new Notification.Builder(getApplicationContext());
            builder.setSmallIcon(R.drawable.on).setTicker("Knock Alarm").setWhen(System.currentTimeMillis())
                    .setNumber(1).setContentTitle("알림").setContentText(formatDate + "에 노크하였습니다.")
                    .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE).setContentIntent(pendingNotificationIntent).setAutoCancel(true);

            notificationmanager.notify(1, builder.build());

        }

        if (theString.equals("3")) {
            switchBell3.setText("ON");
            switchBell3.setBackgroundColor(Color.BLUE);

            long now = System.currentTimeMillis();
            Date date = new Date(now);
            SimpleDateFormat sdfNow = new SimpleDateFormat("MM/dd HH:mm:ss");
            String formatDate = sdfNow.format(date);
            dateNow3.setText(formatDate);    // TextView 에 현재 시간 문자열 할당

            NotificationManager notificationmanager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Intent intent1 = new Intent(MainActivity.this.getApplicationContext(), MainActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingNotificationIntent = PendingIntent.getActivity(MainActivity.this, 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder builder = new Notification.Builder(getApplicationContext());
            builder.setSmallIcon(R.drawable.on).setTicker("\n" + "washer Alarm").setWhen(System.currentTimeMillis())
                    .setNumber(1).setContentTitle("알림").setContentText(formatDate + "에 도어락이 열렸습니다.")
                    .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE).setContentIntent(pendingNotificationIntent).setAutoCancel(true);

            notificationmanager.notify(1, builder.build());

        }

        if (theString.equals("4")) {
            switchBell4.setText("ON");
            switchBell4.setBackgroundColor(Color.RED);

            long now = System.currentTimeMillis();
            Date date = new Date(now);
            SimpleDateFormat sdfNow = new SimpleDateFormat("MM/dd HH:mm:ss");
            String formatDate = sdfNow.format(date);
            dateNow4.setText(formatDate);    // TextView 에 현재 시간 문자열 할당

            NotificationManager notificationmanager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Intent intent1 = new Intent(MainActivity.this.getApplicationContext(), MainActivity.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingNotificationIntent = PendingIntent.getActivity(MainActivity.this, 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder builder = new Notification.Builder(getApplicationContext());
            builder.setSmallIcon(R.drawable.on).setTicker("\n" + "Fire Alarm").setWhen(System.currentTimeMillis())
                    .setNumber(1).setContentTitle("알림").setContentText(formatDate + "에 불이 났습니다.")
                    .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE).setContentIntent(pendingNotificationIntent).setAutoCancel(true);

            notificationmanager.notify(1, builder.build());

        }

    }

}
